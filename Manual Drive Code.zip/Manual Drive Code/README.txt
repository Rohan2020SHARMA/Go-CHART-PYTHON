
Upload Final manual drive code on Teensy 3.2

Upload Pi code files in the home folder of the RPi
add final.py in rc.local

Copy the jetson code in the external PC
Run the combo.py file



